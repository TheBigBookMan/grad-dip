
<nav id="navbar">
    <ul>
        <li><a href="./Homepage.php">Home</a></li>
        <li><a href="./ProductList.php">Products</a></li>
        <li><a href="./ViewCart.php">View Cart</a></li>
        <li><a href="./CustomerList.php">Customers</a></li>
        <li><a href="./OrderList.php">Orders</a></li>
        <li><a href="./SignUp.php">Sign Up</a></li>
    </ul>
</nav>